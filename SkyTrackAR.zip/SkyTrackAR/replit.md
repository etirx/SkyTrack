# SkyTrack - Airport Navigation App

## Overview

This is a modern airport navigation mobile application built with React and Express. The app provides real-time flight information, interactive airport maps, AR-based navigation, and comprehensive airport services directory. It features a mobile-first design with a bottom navigation pattern and aviation-themed UI.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a full-stack architecture with a clear separation between client and server:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: Radix UI with shadcn/ui component library
- **Styling**: Tailwind CSS with custom aviation theme
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **API Design**: RESTful API with JSON responses
- **Session Management**: PostgreSQL session store

## Key Components

### Database Schema
The application uses PostgreSQL with the following main tables:
- `users`: User authentication and profile information
- `flights`: Flight schedules, status, and details
- `airports`: Airport information and metadata
- `airport_services`: Services available at airports (restaurants, shops, etc.)
- `user_flights`: User's saved/tracked flights

### Frontend Pages
- **Home**: Dashboard with quick flight info and airport services
- **Search**: Flight and airport search functionality
- **Map**: Interactive airport terminal maps
- **Flights**: Flight tracking and management
- **Profile**: User settings and preferences
- **AR Navigation**: Augmented reality navigation features

### API Endpoints
- Flight operations: CRUD operations for flights
- Airport operations: Airport and services management
- User operations: Authentication and profile management

## Data Flow

1. **Client Requests**: React components make API calls using TanStack Query
2. **Server Processing**: Express routes handle requests and interact with database
3. **Database Operations**: Drizzle ORM manages PostgreSQL interactions
4. **Response Handling**: JSON responses sent back to client
5. **State Updates**: TanStack Query updates component state automatically

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **drizzle-orm**: Database ORM for PostgreSQL
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI components
- **wouter**: Lightweight React router
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **tsx**: TypeScript execution for development
- **vite**: Build tool and development server
- **esbuild**: Production bundling
- **drizzle-kit**: Database migration tool

## Deployment Strategy

### Development
- Uses Vite dev server with HMR
- TypeScript checking with `tsc`
- Database migrations with `drizzle-kit push`

### Production Build
- Frontend: Vite builds optimized static assets
- Backend: esbuild bundles server code for Node.js
- Database: PostgreSQL hosted on Neon (serverless)

### Environment Configuration
- Uses environment variables for database connection
- Supports both development and production modes
- Replit-optimized with development banner and error handling

### Mobile-First Design
- Responsive design optimized for mobile devices
- Touch-friendly interactions
- Bottom navigation pattern
- Status bar integration
- Floating action button for quick actions

The application is designed to be deployed on Replit with automatic handling of development vs production environments.