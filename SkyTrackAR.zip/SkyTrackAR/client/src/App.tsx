import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "./contexts/theme-context";
import { StatusBar } from "./components/ui/status-bar";
import { BottomNavigation } from "./components/ui/bottom-navigation";
import { FloatingActionButton } from "./components/ui/floating-action-button";
import Home from "./pages/home";
import Search from "./pages/search";
import Map from "./pages/map";
import Flights from "./pages/flights";
import Profile from "./pages/profile";
import ARNavigation from "./pages/ar-navigation";
import NotFound from "./pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/search" component={Search} />
      <Route path="/map" component={Map} />
      <Route path="/flights" component={Flights} />
      <Route path="/profile" component={Profile} />
      <Route path="/ar-navigation" component={ARNavigation} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <div className="mobile-container">
            <StatusBar />
            <div className="pb-20">
              <Router />
            </div>
            <BottomNavigation />
            <FloatingActionButton />
          </div>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
