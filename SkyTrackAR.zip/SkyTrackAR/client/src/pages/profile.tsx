import { useState } from "react";
import { 
  User, 
  Bell, 
  Globe, 
  Moon, 
  Sun, 
  Settings, 
  HelpCircle,
  LogOut,
  Edit,
  Shield,
  Smartphone,
  Plane,
  Star,
  Calendar,
  MapPin
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useTheme } from "@/contexts/theme-context";

export default function Profile() {
  const { theme, toggleTheme } = useTheme();
  const [notifications, setNotifications] = useState(true);
  const [language, setLanguage] = useState("en");

  const user = {
    name: "أحمد محمد",
    email: "ahmed.mohamed@example.com",
    phone: "+966 50 123 4567",
    memberSince: "2023",
    totalFlights: 24,
    milesFlown: 45000,
    favoriteAirport: "RUH",
  };

  const recentFlights = [
    {
      id: 1,
      flightNumber: "SV123",
      route: "RUH → DXB",
      date: "2025-07-16",
      status: "completed",
    },
    {
      id: 2,
      flightNumber: "EK001",
      route: "DXB → LHR",
      date: "2025-07-15",
      status: "completed",
    },
  ];

  const handleLanguageToggle = () => {
    setLanguage(language === "en" ? "ar" : "en");
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="gradient-aviation px-4 py-6 text-white">
        <div className="flex items-center space-x-4">
          <Avatar className="w-16 h-16 border-4 border-white/20">
            <AvatarImage src="/api/placeholder/64/64" alt={user.name} />
            <AvatarFallback className="bg-white/20 text-white text-lg">
              {user.name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h1 className="text-xl font-bold">{user.name}</h1>
            <p className="text-blue-100 text-sm">{user.email}</p>
            <p className="text-blue-100 text-sm">Member since {user.memberSince}</p>
          </div>
          <Button variant="ghost" size="icon" className="text-white">
            <Edit className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="px-4 py-6">
        <div className="grid grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <Plane className="w-6 h-6 text-aviation-blue mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                {user.totalFlights}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Flights</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <Star className="w-6 h-6 text-warning-amber mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                {user.milesFlown.toLocaleString()}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Miles</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <MapPin className="w-6 h-6 text-success-green mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                {user.favoriteAirport}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Favorite</p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Flights */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-aviation-blue" />
              <span>Recent Flights</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentFlights.map((flight) => (
                <div key={flight.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-aviation-blue/10 rounded-full flex items-center justify-center">
                      <Plane className="w-5 h-5 text-aviation-blue" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-800 dark:text-gray-200">
                        {flight.flightNumber}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {flight.route}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {new Date(flight.date).toLocaleDateString()}
                    </p>
                    <Badge variant="outline" className="text-xs">
                      {flight.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Settings className="w-5 h-5 text-aviation-blue" />
              <span>Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Notifications */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Bell className="w-5 h-5 text-gray-500" />
                  <div>
                    <p className="font-medium text-gray-800 dark:text-gray-200">
                      Notifications
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Flight updates and alerts
                    </p>
                  </div>
                </div>
                <Switch
                  checked={notifications}
                  onCheckedChange={setNotifications}
                />
              </div>
              
              <Separator />
              
              {/* Theme */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {theme === "light" ? (
                    <Sun className="w-5 h-5 text-gray-500" />
                  ) : (
                    <Moon className="w-5 h-5 text-gray-500" />
                  )}
                  <div>
                    <p className="font-medium text-gray-800 dark:text-gray-200">
                      Dark Mode
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Switch between light and dark themes
                    </p>
                  </div>
                </div>
                <Switch
                  checked={theme === "dark"}
                  onCheckedChange={toggleTheme}
                />
              </div>
              
              <Separator />
              
              {/* Language */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Globe className="w-5 h-5 text-gray-500" />
                  <div>
                    <p className="font-medium text-gray-800 dark:text-gray-200">
                      Language
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      English / العربية
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleLanguageToggle}
                >
                  {language === "en" ? "العربية" : "English"}
                </Button>
              </div>
              
              <Separator />
              
              {/* Privacy */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Shield className="w-5 h-5 text-gray-500" />
                  <div>
                    <p className="font-medium text-gray-800 dark:text-gray-200">
                      Privacy & Security
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Manage your privacy settings
                    </p>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  Manage
                </Button>
              </div>
              
              <Separator />
              
              {/* Help */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <HelpCircle className="w-5 h-5 text-gray-500" />
                  <div>
                    <p className="font-medium text-gray-800 dark:text-gray-200">
                      Help & Support
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Get help with the app
                    </p>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  Contact
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sign Out */}
        <div className="mt-6">
          <Button variant="outline" className="w-full text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20">
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </div>
    </div>
  );
}
