import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  MapPin, 
  Navigation, 
  Zap, 
  Coffee, 
  ShoppingBag, 
  Car,
  Plane,
  Clock,
  Map as MapIcon,
  Layers,
  Search
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Map() {
  const [selectedTerminal, setSelectedTerminal] = useState("terminal-1");
  const [selectedFloor, setSelectedFloor] = useState("level-2");

  const { data: services } = useQuery({
    queryKey: ["/api/airports/1/services"],
  });

  const { data: flights } = useQuery({
    queryKey: ["/api/flights"],
  });

  const getServiceIcon = (category: string) => {
    switch (category) {
      case "restaurant":
        return <Coffee className="w-4 h-4 text-orange-accent" />;
      case "shopping":
        return <ShoppingBag className="w-4 h-4 text-blue-accent" />;
      case "transport":
        return <Car className="w-4 h-4 text-green-accent" />;
      default:
        return <MapPin className="w-4 h-4 text-gray-500" />;
    }
  };

  const terminals = [
    { id: "terminal-1", name: "Terminal 1", active: true },
    { id: "terminal-2", name: "Terminal 2", active: false },
    { id: "terminal-3", name: "Terminal 3", active: false },
  ];

  const floors = [
    { id: "level-1", name: "Level 1", description: "Arrivals" },
    { id: "level-2", name: "Level 2", description: "Departures" },
    { id: "level-3", name: "Level 3", description: "Shopping" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
              Airport Map
            </h1>
            <Button variant="outline" size="sm">
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
          </div>
          
          {/* Terminal Selector */}
          <div className="flex space-x-2 mb-4">
            {terminals.map((terminal) => (
              <Button
                key={terminal.id}
                variant={selectedTerminal === terminal.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedTerminal(terminal.id)}
                className="flex-1"
              >
                {terminal.name}
              </Button>
            ))}
          </div>
          
          {/* Floor Selector */}
          <div className="flex space-x-2">
            {floors.map((floor) => (
              <Button
                key={floor.id}
                variant={selectedFloor === floor.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedFloor(floor.id)}
                className="flex-1"
              >
                <div className="text-center">
                  <div className="text-xs">{floor.name}</div>
                  <div className="text-xs opacity-75">{floor.description}</div>
                </div>
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Map Container */}
      <div className="px-4 py-6">
        <Card className="mb-6">
          <CardContent className="p-0">
            {/* Interactive Map Placeholder */}
            <div className="h-80 bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg relative overflow-hidden">
              {/* Map Background */}
              <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-blue-100 dark:from-gray-800 dark:to-blue-900/30" />
              
              {/* Terminal Layout */}
              <div className="absolute inset-4 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg">
                <div className="absolute top-2 left-2 bg-white dark:bg-gray-800 px-2 py-1 rounded text-xs font-medium text-gray-600 dark:text-gray-400">
                  Terminal 1 - Level 2
                </div>
                
                {/* Gates */}
                <div className="absolute top-8 left-4 right-4 flex justify-between">
                  {["A1", "A2", "A3", "A4", "A5", "A6"].map((gate) => (
                    <div
                      key={gate}
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium ${
                        gate === "A5" 
                          ? "bg-aviation-blue text-white" 
                          : "bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400"
                      }`}
                    >
                      {gate}
                    </div>
                  ))}
                </div>
                
                {/* Services */}
                <div className="absolute top-16 left-8">
                  <div className="w-6 h-6 bg-orange-accent/20 rounded-full flex items-center justify-center">
                    <Coffee className="w-4 h-4 text-orange-accent" />
                  </div>
                </div>
                
                <div className="absolute top-16 right-8">
                  <div className="w-6 h-6 bg-blue-accent/20 rounded-full flex items-center justify-center">
                    <ShoppingBag className="w-4 h-4 text-blue-accent" />
                  </div>
                </div>
                
                {/* Current Location */}
                <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2">
                  <div className="w-4 h-4 bg-success-green rounded-full animate-pulse-custom">
                    <div className="w-8 h-8 bg-success-green/20 rounded-full absolute -top-2 -left-2 animate-ping" />
                  </div>
                </div>
                
                {/* Direction Arrow */}
                <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 translate-x-8">
                  <div className="text-aviation-blue">
                    <Navigation className="w-6 h-6" />
                  </div>
                </div>
              </div>
              
              {/* Legend */}
              <div className="absolute bottom-4 left-4 bg-white dark:bg-gray-800 p-2 rounded-lg shadow-sm">
                <div className="flex items-center space-x-2 text-xs">
                  <div className="w-3 h-3 bg-success-green rounded-full" />
                  <span className="text-gray-600 dark:text-gray-400">You are here</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Button className="h-auto p-4 flex flex-col items-center space-y-2">
            <Navigation className="w-6 h-6" />
            <span className="text-sm">Navigate to Gate</span>
          </Button>
          <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
            <Zap className="w-6 h-6" />
            <span className="text-sm">Find Nearest</span>
          </Button>
        </div>

        {/* Content Tabs */}
        <Tabs defaultValue="services" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="gates">Gates</TabsTrigger>
            <TabsTrigger value="facilities">Facilities</TabsTrigger>
          </TabsList>
          
          <TabsContent value="services" className="space-y-3">
            {services?.map((service: any) => (
              <Card key={service.id} className="hover-lift transition-all">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
                      {getServiceIcon(service.category)}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-800 dark:text-gray-200">
                        {service.name}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {service.location}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" className="text-xs">
                        2 min
                      </Badge>
                      <p className="text-xs text-success-green mt-1">
                        {service.isOpen ? "Open" : "Closed"}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
          
          <TabsContent value="gates" className="space-y-3">
            {flights?.map((flight: any) => (
              <Card key={flight.id} className="hover-lift transition-all">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-aviation-blue/10 rounded-full flex items-center justify-center">
                      <Plane className="w-5 h-5 text-aviation-blue" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-800 dark:text-gray-200">
                        Gate {flight.gate}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {flight.flightNumber} • {flight.departure} → {flight.arrival}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-1 text-sm text-gray-600 dark:text-gray-400">
                        <Clock className="w-4 h-4" />
                        <span>
                          {new Date(flight.departureTime).toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>
                      <Badge
                        className={
                          flight.status === "boarding"
                            ? "bg-aviation-blue text-white"
                            : "bg-gray-500 text-white"
                        }
                      >
                        {flight.status}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
          
          <TabsContent value="facilities" className="space-y-3">
            {[
              { name: "Restrooms", icon: MapPin, location: "Throughout terminal" },
              { name: "ATM", icon: MapPin, location: "Level 2, Near Gate A3" },
              { name: "Prayer Room", icon: MapPin, location: "Level 2, Quiet Zone" },
              { name: "Charging Stations", icon: Zap, location: "All seating areas" },
              { name: "WiFi", icon: Zap, location: "Throughout terminal" },
            ].map((facility, index) => (
              <Card key={index} className="hover-lift transition-all">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
                      <facility.icon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-800 dark:text-gray-200">
                        {facility.name}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {facility.location}
                      </p>
                    </div>
                    <Button variant="outline" size="sm">
                      <Navigation className="w-4 h-4 mr-2" />
                      Navigate
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
