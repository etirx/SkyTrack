import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search as SearchIcon, Plane, MapPin, Clock, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Search() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("flights");

  const { data: flights, isLoading } = useQuery({
    queryKey: ["/api/flights"],
  });

  const { data: airports } = useQuery({
    queryKey: ["/api/airports"],
  });

  const filteredFlights = flights?.filter((flight: any) =>
    flight.flightNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    flight.departure.toLowerCase().includes(searchQuery.toLowerCase()) ||
    flight.arrival.toLowerCase().includes(searchQuery.toLowerCase()) ||
    flight.airline.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredAirports = airports?.filter((airport: any) =>
    airport.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    airport.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    airport.city.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "boarding":
        return "bg-aviation-blue text-white";
      case "on-time":
        return "bg-success-green text-white";
      case "delayed":
        return "bg-warning-amber text-white";
      case "cancelled":
        return "bg-error-red text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="px-4 py-6">
          <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-4">
            Search
          </h1>
          
          {/* Search Bar */}
          <div className="relative mb-4">
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search flights, airports, or airlines..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-3 text-base"
            />
          </div>

          {/* Filter Button */}
          <div className="flex items-center justify-between">
            <Button variant="outline" className="flex items-center space-x-2">
              <Filter className="w-4 h-4" />
              <span>Filters</span>
            </Button>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {searchQuery && (
                <>
                  {filteredFlights?.length || 0} flights, {filteredAirports?.length || 0} airports
                </>
              )}
            </p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="flights">Flights</TabsTrigger>
            <TabsTrigger value="airports">Airports</TabsTrigger>
          </TabsList>
          
          <TabsContent value="flights" className="mt-6">
            <div className="space-y-4">
              {isLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-4">
                        <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-2" />
                        <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : filteredFlights?.length === 0 ? (
                <div className="text-center py-12">
                  <Plane className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">
                    No flights found
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    Try adjusting your search criteria
                  </p>
                </div>
              ) : (
                filteredFlights?.map((flight: any) => (
                  <Card key={flight.id} className="hover-lift transition-all">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-aviation-blue/10 rounded-full flex items-center justify-center">
                            <Plane className="w-5 h-5 text-aviation-blue" />
                          </div>
                          <div>
                            <p className="font-semibold text-gray-800 dark:text-gray-200">
                              {flight.flightNumber}
                            </p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                              {flight.airline}
                            </p>
                          </div>
                        </div>
                        <Badge className={getStatusColor(flight.status)}>
                          {flight.status}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-lg font-semibold text-gray-800 dark:text-gray-200">
                            {flight.departure} → {flight.arrival}
                          </p>
                          <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                            <div className="flex items-center space-x-1">
                              <Clock className="w-4 h-4" />
                              <span>
                                {new Date(flight.departureTime).toLocaleTimeString([], {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <MapPin className="w-4 h-4" />
                              <span>Gate {flight.gate}</span>
                            </div>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          Track
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="airports" className="mt-6">
            <div className="space-y-4">
              {filteredAirports?.length === 0 ? (
                <div className="text-center py-12">
                  <MapPin className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">
                    No airports found
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    Try adjusting your search criteria
                  </p>
                </div>
              ) : (
                filteredAirports?.map((airport: any) => (
                  <Card key={airport.id} className="hover-lift transition-all">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-blue-accent/10 rounded-full flex items-center justify-center">
                          <MapPin className="w-6 h-6 text-blue-accent" />
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-gray-800 dark:text-gray-200">
                            {airport.name}
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {airport.city}, {airport.country}
                          </p>
                          <p className="text-xs text-gray-400 dark:text-gray-500">
                            {airport.code}
                          </p>
                        </div>
                        <Button variant="outline" size="sm">
                          View Map
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
