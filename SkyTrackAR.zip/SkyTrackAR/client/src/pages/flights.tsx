import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Plane, 
  Clock, 
  MapPin, 
  Bell, 
  Plus,
  Search,
  Filter,
  Star,
  Share2,
  Calendar
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

export default function Flights() {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const { data: flights, isLoading } = useQuery({
    queryKey: ["/api/flights"],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "boarding":
        return "bg-aviation-blue text-white";
      case "on-time":
        return "bg-success-green text-white";
      case "delayed":
        return "bg-warning-amber text-white";
      case "cancelled":
        return "bg-error-red text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "boarding":
        return "Boarding Now";
      case "on-time":
        return "On Time";
      case "delayed":
        return "Delayed";
      case "cancelled":
        return "Cancelled";
      default:
        return status;
    }
  };

  const handleTrackFlight = (flightNumber: string) => {
    toast({
      title: "Flight Tracking Enabled",
      description: `You'll receive notifications about ${flightNumber}`,
    });
  };

  const handleShareFlight = (flight: any) => {
    toast({
      title: "Flight Details Shared",
      description: `${flight.flightNumber} details copied to clipboard`,
    });
  };

  const myFlights = flights?.filter((flight: any) => flight.flightNumber === "SV123");
  const allFlights = flights?.filter((flight: any) => 
    flight.flightNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    flight.departure.toLowerCase().includes(searchQuery.toLowerCase()) ||
    flight.arrival.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
              My Flights
            </h1>
            <Button variant="outline" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Flight
            </Button>
          </div>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search flights..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6">
        <Tabs defaultValue="my-flights" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="my-flights">My Flights</TabsTrigger>
            <TabsTrigger value="all-flights">All Flights</TabsTrigger>
          </TabsList>
          
          <TabsContent value="my-flights" className="space-y-4">
            {myFlights?.length === 0 ? (
              <div className="text-center py-12">
                <Plane className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">
                  No flights tracked
                </h3>
                <p className="text-gray-500 dark:text-gray-400 mb-4">
                  Add flights to track their status and receive updates
                </p>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Your First Flight
                </Button>
              </div>
            ) : (
              myFlights?.map((flight: any) => (
                <Card key={flight.id} className="hover-lift transition-all">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-aviation-blue/10 rounded-full flex items-center justify-center">
                          <Plane className="w-6 h-6 text-aviation-blue" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{flight.flightNumber}</CardTitle>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {flight.airline}
                          </p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(flight.status)}>
                        {getStatusText(flight.status)}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Route */}
                      <div className="flex items-center justify-between">
                        <div className="text-center">
                          <p className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                            {flight.departure}
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {new Date(flight.departureTime).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                        </div>
                        <div className="flex-1 mx-4">
                          <div className="relative">
                            <div className="absolute inset-0 flex items-center">
                              <div className="w-full border-t border-gray-300 dark:border-gray-600" />
                            </div>
                            <div className="relative flex justify-center">
                              <div className="bg-gray-50 dark:bg-gray-900 px-2">
                                <Plane className="w-4 h-4 text-gray-400" />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="text-center">
                          <p className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                            {flight.arrival}
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {new Date(flight.arrivalTime).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                        </div>
                      </div>
                      
                      {/* Details */}
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center space-x-2">
                          <MapPin className="w-4 h-4 text-gray-400" />
                          <span className="text-gray-600 dark:text-gray-400">
                            Gate {flight.gate}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Clock className="w-4 h-4 text-gray-400" />
                          <span className="text-gray-600 dark:text-gray-400">
                            {flight.terminal}
                          </span>
                        </div>
                      </div>
                      
                      {/* Actions */}
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1"
                          onClick={() => handleShareFlight(flight)}
                        >
                          <Share2 className="w-4 h-4 mr-2" />
                          Share
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1"
                          onClick={() => handleTrackFlight(flight.flightNumber)}
                        >
                          <Bell className="w-4 h-4 mr-2" />
                          Notify
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
          
          <TabsContent value="all-flights" className="space-y-4">
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-4">
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-2" />
                      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              allFlights?.map((flight: any) => (
                <Card key={flight.id} className="hover-lift transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-aviation-blue/10 rounded-full flex items-center justify-center">
                          <Plane className="w-5 h-5 text-aviation-blue" />
                        </div>
                        <div>
                          <p className="font-semibold text-gray-800 dark:text-gray-200">
                            {flight.flightNumber}
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {flight.airline}
                          </p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(flight.status)}>
                        {getStatusText(flight.status)}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-lg font-semibold text-gray-800 dark:text-gray-200">
                          {flight.departure} → {flight.arrival}
                        </p>
                        <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                          <div className="flex items-center space-x-1">
                            <Clock className="w-4 h-4" />
                            <span>
                              {new Date(flight.departureTime).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <MapPin className="w-4 h-4" />
                            <span>Gate {flight.gate}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleTrackFlight(flight.flightNumber)}
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Track
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
