import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Camera, 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight,
  Navigation,
  MapPin,
  Clock,
  Plane,
  Zap,
  Settings,
  X,
  Target,
  Eye,
  Maximize2,
  Minimize2,
  Compass,
  Vibrate
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

export default function ARNavigation() {
  const [isARActive, setIsARActive] = useState(false);
  const [currentDirection, setCurrentDirection] = useState("straight");
  const [distanceToGate, setDistanceToGate] = useState(150);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [compassHeading, setCompassHeading] = useState(45);
  const { toast } = useToast();

  const { data: flights } = useQuery({
    queryKey: ["/api/flights"],
  });

  const { data: services } = useQuery({
    queryKey: ["/api/airports/1/services"],
  });

  const currentFlight = flights?.[0];

  // Simulate AR navigation updates
  useEffect(() => {
    if (isARActive) {
      const interval = setInterval(() => {
        setDistanceToGate(prev => Math.max(0, prev - Math.random() * 5));
        setCompassHeading(prev => (prev + Math.random() * 10 - 5) % 360);
        
        const directions = ["straight", "left", "right", "up", "down"];
        setCurrentDirection(directions[Math.floor(Math.random() * directions.length)]);
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [isARActive]);

  const startARNavigation = () => {
    setIsARActive(true);
    toast({
      title: "AR Navigation Started",
      description: "Point your camera and follow the arrows",
    });
  };

  const stopARNavigation = () => {
    setIsARActive(false);
    toast({
      title: "AR Navigation Stopped",
      description: "Navigation session ended",
    });
  };

  const getDirectionIcon = (direction: string) => {
    switch (direction) {
      case "left":
        return <ArrowLeft className="w-6 h-6" />;
      case "right":
        return <ArrowRight className="w-6 h-6" />;
      case "up":
        return <ArrowUp className="w-6 h-6" />;
      case "down":
        return <ArrowDown className="w-6 h-6" />;
      default:
        return <ArrowUp className="w-6 h-6" />;
    }
  };

  const getDirectionColor = (direction: string) => {
    switch (direction) {
      case "left":
        return "bg-warning-amber";
      case "right":
        return "bg-success-green";
      case "up":
        return "bg-aviation-blue";
      case "down":
        return "bg-purple-accent";
      default:
        return "bg-aviation-blue";
    }
  };

  if (!isARActive) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        {/* Header */}
        <div className="bg-white dark:bg-gray-800 shadow-sm">
          <div className="px-4 py-6">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                AR Navigation
              </h1>
              <Link href="/">
                <Button variant="outline" size="sm">
                  <X className="w-4 h-4 mr-2" />
                  Close
                </Button>
              </Link>
            </div>
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              Use augmented reality to navigate to your gate
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="px-4 py-6">
          {/* Current Flight Info */}
          {currentFlight && (
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-aviation-blue/10 rounded-full flex items-center justify-center">
                      <Plane className="w-6 h-6 text-aviation-blue" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800 dark:text-gray-200">
                        {currentFlight.flightNumber}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {currentFlight.departure} → {currentFlight.arrival}
                      </p>
                    </div>
                  </div>
                  <Badge className="bg-aviation-blue text-white">
                    Gate {currentFlight.gate}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600 dark:text-gray-400">
                      {new Date(currentFlight.departureTime).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600 dark:text-gray-400">
                      {currentFlight.terminal}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* AR Preview */}
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg h-64 flex items-center justify-center mb-4 relative overflow-hidden">
                {/* Mock camera feed background */}
                <div className="absolute inset-0 bg-gradient-to-r from-gray-200 to-blue-200 dark:from-gray-700 dark:to-blue-800 opacity-60" />
                
                {/* AR Elements Preview */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-aviation-blue/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Eye className="w-8 h-8 text-aviation-blue" />
                    </div>
                    <p className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">
                      AR Navigation Ready
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Grant camera access to start navigation
                    </p>
                  </div>
                </div>
                
                {/* Mock AR Elements */}
                <div className="absolute top-4 left-4 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-lg px-3 py-2">
                  <div className="flex items-center space-x-2">
                    <Navigation className="w-4 h-4 text-aviation-blue" />
                    <span className="text-sm font-medium text-gray-800 dark:text-gray-200">
                      Gate A5
                    </span>
                  </div>
                </div>
                
                <div className="absolute top-4 right-4 bg-success-green/90 backdrop-blur-sm rounded-full p-2">
                  <ArrowUp className="w-4 h-4 text-white transform rotate-45" />
                </div>
              </div>
              
              <Button 
                onClick={startARNavigation}
                className="w-full gradient-purple text-white hover:opacity-90 transition-all"
                size="lg"
              >
                <Camera className="w-5 h-5 mr-2" />
                Start AR Navigation
              </Button>
            </CardContent>
          </Card>

          {/* Features */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="w-12 h-12 bg-aviation-blue/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Target className="w-6 h-6 text-aviation-blue" />
                </div>
                <p className="font-medium text-gray-800 dark:text-gray-200 mb-1">
                  Precise Navigation
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Turn-by-turn AR guidance
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="w-12 h-12 bg-success-green/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Zap className="w-6 h-6 text-success-green" />
                </div>
                <p className="font-medium text-gray-800 dark:text-gray-200 mb-1">
                  Live Updates
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Real-time gate changes
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Nearby Services */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold text-gray-800 dark:text-gray-200 mb-3">
                Points of Interest
              </h3>
              <div className="space-y-2">
                {services?.slice(0, 3).map((service: any) => (
                  <div key={service.id} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {service.name}
                      </span>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      Navigate
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className={`${isFullscreen ? 'fixed inset-0 z-50' : 'min-h-screen'} bg-black`}>
      {/* AR Camera View */}
      <div className="relative w-full h-full">
        {/* Mock camera feed */}
        <div className="absolute inset-0 bg-gradient-to-br from-gray-800 via-blue-900 to-purple-900 opacity-80" />
        
        {/* AR Overlay Elements */}
        <div className="absolute inset-0">
          {/* Top Status Bar */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
            <div className="bg-black/50 backdrop-blur-sm rounded-lg px-3 py-2">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-success-green rounded-full animate-pulse" />
                <span className="text-white text-sm font-medium">AR Active</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                onClick={() => setIsFullscreen(!isFullscreen)}
                variant="ghost"
                size="icon"
                className="bg-black/50 backdrop-blur-sm text-white hover:bg-black/70"
              >
                {isFullscreen ? (
                  <Minimize2 className="w-5 h-5" />
                ) : (
                  <Maximize2 className="w-5 h-5" />
                )}
              </Button>
              
              <Button
                onClick={stopARNavigation}
                variant="ghost"
                size="icon"
                className="bg-black/50 backdrop-blur-sm text-white hover:bg-black/70"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>
          
          {/* Center Navigation Arrow */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className={`${getDirectionColor(currentDirection)} backdrop-blur-sm rounded-full p-4 shadow-lg animate-pulse-custom`}>
              {getDirectionIcon(currentDirection)}
              <div className="text-white text-center mt-2">
                <p className="text-lg font-bold">{distanceToGate.toFixed(0)}m</p>
                <p className="text-sm opacity-90">to Gate A5</p>
              </div>
            </div>
          </div>
          
          {/* Distance Progress */}
          <div className="absolute top-20 left-4 right-4">
            <div className="bg-black/50 backdrop-blur-sm rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white text-sm">Gate A5</span>
                <span className="text-white text-sm font-medium">
                  {distanceToGate.toFixed(0)}m
                </span>
              </div>
              <Progress 
                value={Math.max(0, 100 - (distanceToGate / 150) * 100)} 
                className="h-2"
              />
            </div>
          </div>
          
          {/* Compass */}
          <div className="absolute top-4 right-20">
            <div className="bg-black/50 backdrop-blur-sm rounded-full p-3">
              <div className="relative">
                <Compass 
                  className="w-8 h-8 text-white" 
                  style={{ transform: `rotate(${compassHeading}deg)` }}
                />
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1 h-1 bg-aviation-blue rounded-full" />
              </div>
            </div>
          </div>
          
          {/* Bottom Info Panel */}
          <div className="absolute bottom-4 left-4 right-4">
            <div className="bg-black/50 backdrop-blur-sm rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-aviation-blue/20 rounded-full flex items-center justify-center">
                    <Plane className="w-5 h-5 text-aviation-blue" />
                  </div>
                  <div>
                    <p className="text-white font-medium">
                      {currentFlight?.flightNumber}
                    </p>
                    <p className="text-white/70 text-sm">
                      Boarding in 45 min
                    </p>
                  </div>
                </div>
                <Badge className="bg-aviation-blue text-white">
                  {currentFlight?.status}
                </Badge>
              </div>
              
              {/* Quick Actions */}
              <div className="grid grid-cols-3 gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-white hover:bg-white/20"
                >
                  <MapPin className="w-4 h-4 mr-2" />
                  POI
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-white hover:bg-white/20"
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-white hover:bg-white/20"
                >
                  <Vibrate className="w-4 h-4 mr-2" />
                  Alerts
                </Button>
              </div>
            </div>
          </div>
          
          {/* POI Markers */}
          <div className="absolute top-1/3 left-1/4">
            <div className="bg-orange-accent/90 backdrop-blur-sm rounded-lg px-2 py-1">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-white rounded-full" />
                <span className="text-white text-xs">Coffee Shop</span>
              </div>
            </div>
          </div>
          
          <div className="absolute top-1/2 right-1/4">
            <div className="bg-blue-accent/90 backdrop-blur-sm rounded-lg px-2 py-1">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-white rounded-full" />
                <span className="text-white text-xs">Duty Free</span>
              </div>
            </div>
          </div>
          
          {/* Path Indicators */}
          <div className="absolute bottom-32 left-1/2 transform -translate-x-1/2">
            <div className="flex space-x-2">
              {[1, 2, 3, 4, 5].map((dot) => (
                <div
                  key={dot}
                  className={`w-3 h-3 rounded-full ${
                    dot <= 3 ? 'bg-aviation-blue' : 'bg-white/30'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
