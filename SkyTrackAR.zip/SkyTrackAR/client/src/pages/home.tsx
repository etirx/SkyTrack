import { useQuery } from "@tanstack/react-query";
import { 
  Route, 
  Plane, 
  Map, 
  Leaf, 
  Bell, 
  User, 
  Star,
  Coffee,
  ShoppingBag,
  Car,
  Eye,
  Camera,
  ArrowRight,
  ArrowUp,
  MapPin
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Home() {
  const { data: flights, isLoading } = useQuery({
    queryKey: ["/api/flights"],
  });

  const { data: services } = useQuery({
    queryKey: ["/api/airports/1/services"],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "boarding":
        return "bg-aviation-blue text-white";
      case "on-time":
        return "bg-success-green text-white";
      case "delayed":
        return "bg-warning-amber text-white";
      case "cancelled":
        return "bg-error-red text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const getServiceIcon = (category: string, className = "w-5 h-5") => {
    switch (category) {
      case "restaurant":
        return <Coffee className={className} />;
      case "shopping":
        return <ShoppingBag className={className} />;
      case "transport":
        return <Car className={className} />;
      default:
        return <Star className={className} />;
    }
  };

  const currentFlight = flights?.[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-purple-900/20">
      {/* Header */}
      <div className="gradient-aviation px-4 py-8 text-white relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-32 h-32 bg-white rounded-full -translate-x-16 -translate-y-16"></div>
          <div className="absolute top-20 right-0 w-24 h-24 bg-white rounded-full translate-x-12 -translate-y-12"></div>
          <div className="absolute bottom-0 left-1/2 w-40 h-40 bg-white rounded-full -translate-x-20 translate-y-20"></div>
        </div>
        
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold mb-1">SkyTrack AR</h1>
              <p className="text-blue-100 text-sm flex items-center">
                <span className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></span>
                مرحباً، أحمد
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="icon"
                className="p-2 bg-white/20 hover:bg-white/30 rounded-full backdrop-blur-sm"
              >
                <Bell className="w-5 h-5 text-white" />
              </Button>
              <Link href="/profile">
                <div className="w-12 h-12 bg-gradient-to-br from-white/30 to-white/10 rounded-full flex items-center justify-center backdrop-blur-sm border border-white/20">
                  <User className="w-6 h-6 text-white" />
                </div>
              </Link>
            </div>
          </div>
        
        {/* Quick Flight Status */}
        {currentFlight && (
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-lg font-semibold text-white">
                      {currentFlight.departure} → {currentFlight.arrival}
                    </span>
                    <Badge className={getStatusColor(currentFlight.status)}>
                      {currentFlight.status === "boarding" ? "Boarding" : "On Time"}
                    </Badge>
                  </div>
                  <p className="text-blue-100 text-sm">
                    Flight {currentFlight.flightNumber} • Gate {currentFlight.gate}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-semibold text-white">
                    {new Date(currentFlight.departureTime).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                  <p className="text-blue-100 text-sm">Boarding</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-6">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">
          Quick Actions
        </h2>
        <div className="grid grid-cols-2 gap-4">
          <Link href="/ar-navigation">
            <Button
              variant="outline"
              className="w-full h-auto p-6 flex flex-col items-center space-y-3 hover-lift transition-all border-2 hover:border-aviation-blue/30 group bg-gradient-to-br from-white to-blue-50 dark:from-gray-800 dark:to-gray-700 shadow-lg"
            >
              <div className="w-16 h-16 gradient-aviation rounded-2xl flex items-center justify-center transform group-hover:scale-105 transition-transform shadow-md">
                <Route className="w-8 h-8 text-white" />
              </div>
              <div className="text-center">
                <p className="font-semibold text-sm text-gray-900 dark:text-gray-100">AR Navigation</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Find your way</p>
              </div>
            </Button>
          </Link>
          
          <Link href="/flights">
            <Button
              variant="outline"
              className="w-full h-auto p-6 flex flex-col items-center space-y-3 hover-lift transition-all border-2 hover:border-success-green/30 group bg-gradient-to-br from-white to-green-50 dark:from-gray-800 dark:to-gray-700 shadow-lg"
            >
              <div className="w-16 h-16 gradient-mint rounded-2xl flex items-center justify-center transform group-hover:scale-105 transition-transform shadow-md">
                <Plane className="w-8 h-8 text-white" />
              </div>
              <div className="text-center">
                <p className="font-semibold text-sm text-gray-900 dark:text-gray-100">Track Flight</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Live updates</p>
              </div>
            </Button>
          </Link>
          
          <Link href="/map">
            <Button
              variant="outline"
              className="w-full h-auto p-6 flex flex-col items-center space-y-3 hover-lift transition-all border-2 hover:border-warning-amber/30 group bg-gradient-to-br from-white to-yellow-50 dark:from-gray-800 dark:to-gray-700 shadow-lg"
            >
              <div className="w-16 h-16 gradient-sunset rounded-2xl flex items-center justify-center transform group-hover:scale-105 transition-transform shadow-md">
                <Map className="w-8 h-8 text-white" />
              </div>
              <div className="text-center">
                <p className="font-semibold text-sm text-gray-900 dark:text-gray-100">Airport Map</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Explore terminals</p>
              </div>
            </Button>
          </Link>
          
          <Button
            variant="outline"
            className="w-full h-auto p-6 flex flex-col items-center space-y-3 hover-lift transition-all border-2 hover:border-purple-accent/30 group bg-gradient-to-br from-white to-purple-50 dark:from-gray-800 dark:to-gray-700 shadow-lg"
          >
            <div className="w-16 h-16 gradient-royal rounded-2xl flex items-center justify-center transform group-hover:scale-105 transition-transform shadow-md">
              <Leaf className="w-8 h-8 text-white" />
            </div>
            <div className="text-center">
              <p className="font-semibold text-sm text-gray-900 dark:text-gray-100">Carbon Offset</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">Go green</p>
            </div>
          </Button>
        </div>
      </div>

      {/* Nearby Services */}
      <div className="px-4 py-6 bg-gradient-to-br from-gray-50 to-blue-50/30 dark:from-gray-800/50 dark:to-blue-900/10">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-200">
            Nearby Services
          </h2>
          <Button variant="link" className="text-aviation-blue text-sm font-medium hover:text-deep-blue">
            View All
          </Button>
        </div>
        
        <div className="space-y-4">
          {services?.slice(0, 3).map((service: any, index: number) => (
            <Card key={service.id} className="hover-lift transition-all bg-white/80 dark:bg-gray-700/80 backdrop-blur-sm border border-white/20 hover:shadow-lg">
              <CardContent className="p-4">
                <div className="flex items-center space-x-4">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
                    index === 0 ? 'gradient-sunset' : 
                    index === 1 ? 'gradient-ocean' : 
                    'gradient-mint'
                  }`}>
                    {getServiceIcon(service.category, "w-7 h-7 text-white")}
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-gray-800 dark:text-gray-200 mb-1">
                      {service.name}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                      <MapPin className="w-3 h-3 mr-1" />
                      {service.location} • 2 min walk
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-1 bg-yellow-50 dark:bg-yellow-900/20 px-2 py-1 rounded-full mb-2">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span className="text-sm font-medium text-yellow-700 dark:text-yellow-300">
                        {service.rating}
                      </span>
                    </div>
                    <p className={`text-xs font-medium px-2 py-1 rounded-full ${
                      service.isOpen 
                        ? 'text-green-700 bg-green-50 dark:text-green-300 dark:bg-green-900/20' 
                        : 'text-red-700 bg-red-50 dark:text-red-300 dark:bg-red-900/20'
                    }`}>
                      {service.isOpen ? "Open" : "Closed"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Flight Updates */}
      <div className="px-4 py-6">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">
          Flight Updates
        </h2>
        
        <div className="space-y-3">
          {currentFlight && (
            <Card className="gradient-success text-white">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm opacity-90">Your Flight</span>
                  <Badge className="bg-white/20 text-white">On Time</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-lg font-semibold">
                      {currentFlight.departure} → {currentFlight.arrival}
                    </p>
                    <p className="text-sm opacity-90">
                      {currentFlight.flightNumber} • {currentFlight.gate}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-semibold">
                      {new Date(currentFlight.departureTime).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                    <p className="text-sm opacity-90">Boarding in 45 min</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          
          {flights?.[1] && (
            <Card className="hover-lift transition-all">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    Connecting Flight
                  </span>
                  <Badge className="bg-warning-amber/20 text-warning-amber">
                    Delayed
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-gray-800 dark:text-gray-200">
                      {flights[1].departure} → {flights[1].arrival}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {flights[1].flightNumber} • {flights[1].gate}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-800 dark:text-gray-200">
                      {new Date(flights[1].departureTime).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                    <p className="text-sm text-warning-amber">Delayed 30 min</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* AR Preview */}
      <div className="px-4 py-6 bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20">
        <Card className="border-purple-200 dark:border-purple-800">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-purple-accent/10 rounded-full flex items-center justify-center">
                <Eye className="w-6 h-6 text-purple-accent" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-800 dark:text-gray-200">
                  AR Navigation Ready
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Point your camera to start
                </p>
              </div>
            </div>
            
            {/* AR Preview Mock */}
            <div className="bg-gray-100 dark:bg-gray-800 rounded-lg h-32 flex items-center justify-center mb-4 relative overflow-hidden">
              {/* Mock camera feed background */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900 dark:to-purple-900 opacity-60" />
              
              {/* AR Overlay Elements */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-aviation-blue/90 backdrop-blur-sm rounded-lg px-4 py-2 text-white">
                  <div className="flex items-center space-x-2">
                    <ArrowRight className="w-4 h-4" />
                    <span className="font-medium">Gate A5 - 150m</span>
                  </div>
                </div>
              </div>
              
              {/* AR Direction Arrow */}
              <div className="absolute top-4 right-4 bg-success-green/90 backdrop-blur-sm rounded-full p-2">
                <ArrowUp className="w-4 h-4 text-white transform rotate-45" />
              </div>
            </div>
            
            <Link href="/ar-navigation">
              <Button className="w-full gradient-purple text-white hover:opacity-90 transition-all">
                <Camera className="w-4 h-4 mr-2" />
                Start AR Navigation
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
