import { Info, X } from "lucide-react";
import { useState, useEffect } from "react";

interface NotificationToastProps {
  title: string;
  message: string;
  type?: "info" | "warning" | "error" | "success";
  autoHide?: boolean;
  onClose?: () => void;
}

export function NotificationToast({
  title,
  message,
  type = "info",
  autoHide = true,
  onClose,
}: NotificationToastProps) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    if (autoHide) {
      const timer = setTimeout(() => {
        setIsVisible(false);
        setTimeout(() => onClose?.(), 300);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [autoHide, onClose]);

  if (!isVisible) return null;

  const getTypeStyles = () => {
    switch (type) {
      case "warning":
        return "border-warning-amber";
      case "error":
        return "border-error-red";
      case "success":
        return "border-success-green";
      default:
        return "border-aviation-blue";
    }
  };

  const getIconColor = () => {
    switch (type) {
      case "warning":
        return "text-warning-amber";
      case "error":
        return "text-error-red";
      case "success":
        return "text-success-green";
      default:
        return "text-aviation-blue";
    }
  };

  return (
    <div className="fixed top-20 left-4 right-4 z-50 max-w-sm mx-auto">
      <div className={`bg-white dark:bg-gray-800 shadow-lg rounded-lg p-4 border-l-4 ${getTypeStyles()} transform transition-all duration-300 animate-fade-in`}>
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
            <Info className={`w-4 h-4 ${getIconColor()}`} />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-gray-800 dark:text-gray-200">{title}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{message}</p>
          </div>
          <button
            onClick={() => {
              setIsVisible(false);
              setTimeout(() => onClose?.(), 300);
            }}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 touch-friendly"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
