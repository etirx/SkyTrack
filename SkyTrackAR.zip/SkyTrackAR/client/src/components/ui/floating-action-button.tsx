import { QrCode } from "lucide-react";
import { Button } from "./button";

interface FloatingActionButtonProps {
  onClick?: () => void;
}

export function FloatingActionButton({ onClick }: FloatingActionButtonProps) {
  return (
    <div className="fixed bottom-24 right-6 max-w-sm mx-auto">
      <Button
        onClick={onClick}
        className="gradient-aviation hover:gradient-royal text-white p-4 rounded-full shadow-xl hover:shadow-2xl touch-friendly transition-all hover-lift transform hover:scale-110 active:scale-95 backdrop-blur-sm border border-white/20"
        size="icon"
      >
        <QrCode className="w-7 h-7" />
      </Button>
    </div>
  );
}
