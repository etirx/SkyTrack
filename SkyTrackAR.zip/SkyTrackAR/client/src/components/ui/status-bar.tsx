import { Signal, Wifi, Battery } from "lucide-react";

export function StatusBar() {
  const currentTime = new Date().toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  return (
    <div className="bg-aviation-blue text-white px-4 py-2 flex justify-between items-center text-sm">
      <span className="font-medium">{currentTime}</span>
      <div className="flex items-center space-x-2">
        <Signal className="w-4 h-4" />
        <Wifi className="w-4 h-4" />
        <Battery className="w-4 h-4" />
      </div>
    </div>
  );
}
