import { Home, Search, Map, Plane, User } from "lucide-react";
import { useLocation } from "wouter";
import { Link } from "wouter";

const navigationItems = [
  { path: "/", icon: Home, label: "Home", color: "aviation-blue" },
  { path: "/search", icon: Search, label: "Search", color: "purple-accent" },
  { path: "/map", icon: Map, label: "Map", color: "warning-amber" },
  { path: "/flights", icon: Plane, label: "Flights", color: "success-green" },
  { path: "/profile", icon: User, label: "Profile", color: "orange-accent" },
];

export function BottomNavigation() {
  const [location] = useLocation();

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-gray-800/95 backdrop-blur-sm border-t border-gray-200/50 dark:border-gray-700/50 shadow-lg">
      <div className="max-w-sm mx-auto">
        <div className="flex items-center justify-around py-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <Link
                key={item.path}
                href={item.path}
                className={`flex flex-col items-center py-2 px-4 touch-friendly transition-all duration-200 ${
                  isActive 
                    ? `text-${item.color} scale-105` 
                    : "text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 hover:scale-105"
                }`}
              >
                <div className={`rounded-full p-2 transition-all duration-200 ${
                  isActive 
                    ? `bg-${item.color}/10 shadow-md` 
                    : "hover:bg-gray-100 dark:hover:bg-gray-700"
                }`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-xs font-medium mt-1">{item.label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
