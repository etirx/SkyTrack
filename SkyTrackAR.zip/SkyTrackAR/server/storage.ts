import { 
  users, 
  flights, 
  airports, 
  airportServices, 
  userFlights,
  type User, 
  type InsertUser,
  type Flight,
  type InsertFlight,
  type Airport,
  type InsertAirport,
  type AirportService,
  type InsertAirportService,
  type UserFlight,
  type InsertUserFlight
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Flight operations
  getFlight(id: number): Promise<Flight | undefined>;
  getFlightByNumber(flightNumber: string): Promise<Flight | undefined>;
  getAllFlights(): Promise<Flight[]>;
  createFlight(flight: InsertFlight): Promise<Flight>;
  updateFlightStatus(id: number, status: string, gate?: string): Promise<Flight | undefined>;
  
  // Airport operations
  getAirport(id: number): Promise<Airport | undefined>;
  getAirportByCode(code: string): Promise<Airport | undefined>;
  getAllAirports(): Promise<Airport[]>;
  createAirport(airport: InsertAirport): Promise<Airport>;
  
  // Airport services operations
  getAirportServices(airportId: number): Promise<AirportService[]>;
  getAirportServicesByCategory(airportId: number, category: string): Promise<AirportService[]>;
  createAirportService(service: InsertAirportService): Promise<AirportService>;
  
  // User flights operations
  getUserFlights(userId: number): Promise<UserFlight[]>;
  createUserFlight(userFlight: InsertUserFlight): Promise<UserFlight>;
  deleteUserFlight(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private flights: Map<number, Flight>;
  private airports: Map<number, Airport>;
  private airportServices: Map<number, AirportService>;
  private userFlights: Map<number, UserFlight>;
  private currentUserId: number;
  private currentFlightId: number;
  private currentAirportId: number;
  private currentServiceId: number;
  private currentUserFlightId: number;

  constructor() {
    this.users = new Map();
    this.flights = new Map();
    this.airports = new Map();
    this.airportServices = new Map();
    this.userFlights = new Map();
    this.currentUserId = 1;
    this.currentFlightId = 1;
    this.currentAirportId = 1;
    this.currentServiceId = 1;
    this.currentUserFlightId = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample airports
    const ruhAirport: Airport = {
      id: this.currentAirportId++,
      code: "RUH",
      name: "King Khalid International Airport",
      city: "Riyadh",
      country: "Saudi Arabia",
      timezone: "Asia/Riyadh",
      createdAt: new Date(),
    };
    
    const dxbAirport: Airport = {
      id: this.currentAirportId++,
      code: "DXB",
      name: "Dubai International Airport",
      city: "Dubai",
      country: "United Arab Emirates",
      timezone: "Asia/Dubai",
      createdAt: new Date(),
    };
    
    this.airports.set(ruhAirport.id, ruhAirport);
    this.airports.set(dxbAirport.id, dxbAirport);
    
    // Sample flights
    const flight1: Flight = {
      id: this.currentFlightId++,
      flightNumber: "SV123",
      airline: "Saudi Arabian Airlines",
      departure: "RUH",
      arrival: "DXB",
      departureTime: new Date("2025-07-16T14:25:00"),
      arrivalTime: new Date("2025-07-16T17:15:00"),
      gate: "A5",
      terminal: "Terminal 1",
      status: "boarding",
      aircraft: "Boeing 777",
      createdAt: new Date(),
    };
    
    const flight2: Flight = {
      id: this.currentFlightId++,
      flightNumber: "EK001",
      airline: "Emirates",
      departure: "DXB",
      arrival: "LHR",
      departureTime: new Date("2025-07-16T22:45:00"),
      arrivalTime: new Date("2025-07-17T02:30:00"),
      gate: "B12",
      terminal: "Terminal 3",
      status: "delayed",
      aircraft: "Airbus A380",
      createdAt: new Date(),
    };
    
    this.flights.set(flight1.id, flight1);
    this.flights.set(flight2.id, flight2);
    
    // Sample airport services
    const services: AirportService[] = [
      {
        id: this.currentServiceId++,
        airportId: ruhAirport.id,
        name: "Costa Coffee",
        category: "restaurant",
        location: "Terminal 1, Level 2",
        description: "Premium coffee and light meals",
        rating: "4.5",
        isOpen: true,
        openingHours: "24/7",
        createdAt: new Date(),
      },
      {
        id: this.currentServiceId++,
        airportId: ruhAirport.id,
        name: "Duty Free",
        category: "shopping",
        location: "Terminal 1, Level 3",
        description: "Tax-free shopping for travelers",
        rating: "4.2",
        isOpen: true,
        openingHours: "24/7",
        createdAt: new Date(),
      },
      {
        id: this.currentServiceId++,
        airportId: ruhAirport.id,
        name: "Taxi & Ride Share",
        category: "transport",
        location: "Ground Level",
        description: "Taxi and ride-sharing services",
        rating: "4.0",
        isOpen: true,
        openingHours: "24/7",
        createdAt: new Date(),
      },
    ];
    
    services.forEach(service => {
      this.airportServices.set(service.id, service);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, createdAt: new Date(), preferredLanguage: insertUser.preferredLanguage || "en" };
    this.users.set(id, user);
    return user;
  }

  async getFlight(id: number): Promise<Flight | undefined> {
    return this.flights.get(id);
  }

  async getFlightByNumber(flightNumber: string): Promise<Flight | undefined> {
    return Array.from(this.flights.values()).find(flight => flight.flightNumber === flightNumber);
  }

  async getAllFlights(): Promise<Flight[]> {
    return Array.from(this.flights.values());
  }

  async createFlight(insertFlight: InsertFlight): Promise<Flight> {
    const id = this.currentFlightId++;
    const flight: Flight = { 
      ...insertFlight, 
      id, 
      createdAt: new Date(), 
      status: insertFlight.status || "scheduled",
      gate: insertFlight.gate || null,
      terminal: insertFlight.terminal || null,
      aircraft: insertFlight.aircraft || null
    };
    this.flights.set(id, flight);
    return flight;
  }

  async updateFlightStatus(id: number, status: string, gate?: string): Promise<Flight | undefined> {
    const flight = this.flights.get(id);
    if (flight) {
      flight.status = status;
      if (gate) flight.gate = gate;
      this.flights.set(id, flight);
      return flight;
    }
    return undefined;
  }

  async getAirport(id: number): Promise<Airport | undefined> {
    return this.airports.get(id);
  }

  async getAirportByCode(code: string): Promise<Airport | undefined> {
    return Array.from(this.airports.values()).find(airport => airport.code === code);
  }

  async getAllAirports(): Promise<Airport[]> {
    return Array.from(this.airports.values());
  }

  async createAirport(insertAirport: InsertAirport): Promise<Airport> {
    const id = this.currentAirportId++;
    const airport: Airport = { ...insertAirport, id, createdAt: new Date() };
    this.airports.set(id, airport);
    return airport;
  }

  async getAirportServices(airportId: number): Promise<AirportService[]> {
    return Array.from(this.airportServices.values()).filter(service => service.airportId === airportId);
  }

  async getAirportServicesByCategory(airportId: number, category: string): Promise<AirportService[]> {
    return Array.from(this.airportServices.values()).filter(
      service => service.airportId === airportId && service.category === category
    );
  }

  async createAirportService(insertService: InsertAirportService): Promise<AirportService> {
    const id = this.currentServiceId++;
    const service: AirportService = { 
      ...insertService, 
      id, 
      createdAt: new Date(), 
      isOpen: insertService.isOpen !== undefined ? insertService.isOpen : true,
      description: insertService.description || null,
      rating: insertService.rating || null,
      openingHours: insertService.openingHours || null
    };
    this.airportServices.set(id, service);
    return service;
  }

  async getUserFlights(userId: number): Promise<UserFlight[]> {
    return Array.from(this.userFlights.values()).filter(userFlight => userFlight.userId === userId);
  }

  async createUserFlight(insertUserFlight: InsertUserFlight): Promise<UserFlight> {
    const id = this.currentUserFlightId++;
    const userFlight: UserFlight = { 
      ...insertUserFlight, 
      id, 
      createdAt: new Date(), 
      isTracking: insertUserFlight.isTracking !== undefined ? insertUserFlight.isTracking : true,
      bookingReference: insertUserFlight.bookingReference || null,
      seatNumber: insertUserFlight.seatNumber || null
    };
    this.userFlights.set(id, userFlight);
    return userFlight;
  }

  async deleteUserFlight(id: number): Promise<boolean> {
    return this.userFlights.delete(id);
  }
}

export const storage = new MemStorage();
