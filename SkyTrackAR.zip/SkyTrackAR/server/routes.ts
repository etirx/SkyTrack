import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertFlightSchema, insertAirportSchema, insertAirportServiceSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Flight routes
  app.get("/api/flights", async (req, res) => {
    try {
      const flights = await storage.getAllFlights();
      res.json(flights);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch flights" });
    }
  });

  app.get("/api/flights/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const flight = await storage.getFlight(id);
      if (!flight) {
        return res.status(404).json({ message: "Flight not found" });
      }
      res.json(flight);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch flight" });
    }
  });

  app.get("/api/flights/search/:flightNumber", async (req, res) => {
    try {
      const flightNumber = req.params.flightNumber;
      const flight = await storage.getFlightByNumber(flightNumber);
      if (!flight) {
        return res.status(404).json({ message: "Flight not found" });
      }
      res.json(flight);
    } catch (error) {
      res.status(500).json({ message: "Failed to search flight" });
    }
  });

  app.post("/api/flights", async (req, res) => {
    try {
      const validatedData = insertFlightSchema.parse(req.body);
      const flight = await storage.createFlight(validatedData);
      res.status(201).json(flight);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid flight data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create flight" });
    }
  });

  app.patch("/api/flights/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, gate } = req.body;
      const flight = await storage.updateFlightStatus(id, status, gate);
      if (!flight) {
        return res.status(404).json({ message: "Flight not found" });
      }
      res.json(flight);
    } catch (error) {
      res.status(500).json({ message: "Failed to update flight status" });
    }
  });

  // Airport routes
  app.get("/api/airports", async (req, res) => {
    try {
      const airports = await storage.getAllAirports();
      res.json(airports);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch airports" });
    }
  });

  app.get("/api/airports/:code", async (req, res) => {
    try {
      const code = req.params.code.toUpperCase();
      const airport = await storage.getAirportByCode(code);
      if (!airport) {
        return res.status(404).json({ message: "Airport not found" });
      }
      res.json(airport);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch airport" });
    }
  });

  app.post("/api/airports", async (req, res) => {
    try {
      const validatedData = insertAirportSchema.parse(req.body);
      const airport = await storage.createAirport(validatedData);
      res.status(201).json(airport);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid airport data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create airport" });
    }
  });

  // Airport services routes
  app.get("/api/airports/:airportId/services", async (req, res) => {
    try {
      const airportId = parseInt(req.params.airportId);
      const category = req.query.category as string;
      
      let services;
      if (category) {
        services = await storage.getAirportServicesByCategory(airportId, category);
      } else {
        services = await storage.getAirportServices(airportId);
      }
      
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch airport services" });
    }
  });

  app.post("/api/airports/:airportId/services", async (req, res) => {
    try {
      const airportId = parseInt(req.params.airportId);
      const validatedData = insertAirportServiceSchema.parse({
        ...req.body,
        airportId,
      });
      const service = await storage.createAirportService(validatedData);
      res.status(201).json(service);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid service data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create airport service" });
    }
  });

  // User flights routes
  app.get("/api/users/:userId/flights", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const userFlights = await storage.getUserFlights(userId);
      res.json(userFlights);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user flights" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
