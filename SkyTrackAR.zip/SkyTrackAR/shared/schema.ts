import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  preferredLanguage: text("preferred_language").notNull().default("en"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const flights = pgTable("flights", {
  id: serial("id").primaryKey(),
  flightNumber: text("flight_number").notNull(),
  airline: text("airline").notNull(),
  departure: text("departure").notNull(),
  arrival: text("arrival").notNull(),
  departureTime: timestamp("departure_time").notNull(),
  arrivalTime: timestamp("arrival_time").notNull(),
  gate: text("gate"),
  terminal: text("terminal"),
  status: text("status").notNull().default("scheduled"),
  aircraft: text("aircraft"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const airports = pgTable("airports", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  city: text("city").notNull(),
  country: text("country").notNull(),
  timezone: text("timezone").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const airportServices = pgTable("airport_services", {
  id: serial("id").primaryKey(),
  airportId: integer("airport_id").notNull(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  location: text("location").notNull(),
  description: text("description"),
  rating: decimal("rating", { precision: 3, scale: 2 }),
  isOpen: boolean("is_open").notNull().default(true),
  openingHours: text("opening_hours"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userFlights = pgTable("user_flights", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  flightId: integer("flight_id").notNull(),
  bookingReference: text("booking_reference"),
  seatNumber: text("seat_number"),
  isTracking: boolean("is_tracking").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertFlightSchema = createInsertSchema(flights).omit({
  id: true,
  createdAt: true,
});

export const insertAirportSchema = createInsertSchema(airports).omit({
  id: true,
  createdAt: true,
});

export const insertAirportServiceSchema = createInsertSchema(airportServices).omit({
  id: true,
  createdAt: true,
});

export const insertUserFlightSchema = createInsertSchema(userFlights).omit({
  id: true,
  createdAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Flight = typeof flights.$inferSelect;
export type InsertFlight = z.infer<typeof insertFlightSchema>;
export type Airport = typeof airports.$inferSelect;
export type InsertAirport = z.infer<typeof insertAirportSchema>;
export type AirportService = typeof airportServices.$inferSelect;
export type InsertAirportService = z.infer<typeof insertAirportServiceSchema>;
export type UserFlight = typeof userFlights.$inferSelect;
export type InsertUserFlight = z.infer<typeof insertUserFlightSchema>;
